void init_keyboard();
