#ifndef TIMER_H
#define TIMER_H

#include "type.h"

void init_timer(u32 freq);

#endif
